# Voice Notes

Record audio in the browser, transcribe it locally with **whisper.cpp**, save the transcript to a
text file, and get a short bullet list of the key moments from a **local LLM**. Nothing leaves your machine.

```
browser mic ─▶ Flask (app.py) ─▶ ffmpeg (16 kHz WAV) ─▶ whisper-cli ─▶ transcripts/<id>.txt
                                                                 └──▶ local LLM ─▶ transcripts/<id>.summary.txt
```

## Run (macOS and Linux)

```bash
./run.sh
```

On first run it checks everything the app needs, sets up what's missing, then opens
http://localhost:5050. It asks before installing anything system-wide or downloading large files:

| Needed | If missing, `run.sh`… |
|---|---|
| Python 3.9+ | offers to install it with your Linux package manager (macOS: `xcode-select --install`) |
| Python packages | creates `.venv` and installs them (a broken or copied `.venv` is rebuilt) |
| ffmpeg | uses the system one, or installs a private copy into `.venv` (no admin rights) |
| whisper.cpp | uses the system one (`brew install whisper-cpp`), or offers Homebrew, or builds it from source into `vendor/` (needs a C++ compiler; on Linux it offers to install one) |
| Speech model | offers to download Small (488 MB, all languages) |
| Local LLM (optional) | reports whether LM Studio or Ollama is available |

Admin rights (`sudo`) are only needed on Linux if Python, its venv module (Debian/Ubuntu) or a
C++ compiler is missing. Supported package managers: apt, dnf, pacman, zypper, apk.

```bash
./run.sh --check   # report what's installed, change nothing
./run.sh --yes     # accept every step without asking (for scripts; no terminal = "no" otherwise)
PORT=5051 ./run.sh # another port; NO_BROWSER=1 skips opening the browser
```

Then turn the models on in the **Models** panel (top right).

**Linux notes.** When whisper.cpp is built from source, it uses the GPU automatically if the NVIDIA
CUDA toolkit (`nvcc`) is installed; otherwise it runs on the CPU, where the Small or compressed
models are the practical choice. Other GPU back-ends can be enabled with e.g.
`WHISPER_CMAKE_FLAGS="-DGGML_VULKAN=ON" ./run.sh` (delete `vendor/` first to rebuild).
For key moments, LM Studio has a Linux version, or use Ollama via **Other server**.
Recording from the microphone works in Chrome, Firefox and Edge.

## Sharing the app

```bash
./package.sh       # creates dist/voice-notes-<date>.tar.gz (~40 KB)
```

The archive contains only the program: no recordings, transcripts, models, settings or `.venv`.
On the other computer:

```bash
tar -xzf voice-notes-*.tar.gz && cd voice-notes && ./run.sh
```

Windows is not supported directly; use WSL (Ubuntu), where the Linux instructions apply.

## Using it

- Click **Record**, speak, click **Stop**.
- Or **add existing recordings**: drop audio/video files anywhere on the page, or click *browse files*.
  You can add several at once (Voice Memos `.m4a`, WhatsApp/Telegram `.ogg`/`.opus`, `.mp3`, `.wav`,
  `.flac`, `.webm`, `.mp4`, …). They are processed one after another in the **Queue**; you can keep
  recording while it runs. The file name becomes the title.
- The transcript appears with timestamps. Click a timestamp to jump the audio player there.
- **Key moments** lists the 3–7 most important points, each linked to its timestamp.
- Earlier recordings are in the **History** sidebar.

## Local models (the Models panel)

Click the status pills in the top-right corner.

**Speech to text (Whisper)**
- **On/Off**: *On* keeps the model loaded in a `whisper-server` process, so transcription starts
  right away. *Off* frees that memory; each file then loads the model with `whisper-cli` just for
  the job. Transcription works either way. The setting is remembered between app restarts.
- **Spoken language**: auto-detect, or pick any of Whisper's 100 languages (Finnish, Estonian,
  Ukrainian, Japanese, …); there's a search box. Picking the language is more reliable for short clips.
  A hint under the picker recommends the best model for the chosen language and warns about mismatches
  (for example, an English-only model with Finnish speech).
- **General models** (all languages): Tiny → Large v3, downloaded with a progress bar (and cancel).
  *Large v3 Turbo (compressed)*, 574 MB, is the recommended choice for most non-English languages.
  Unused models can be deleted. Switching while on reloads the server with the new model.
- **Language packs**: models fine-tuned for a single language, downloaded the same way:
  - **Swedish**: KB-Whisper by KBLab, National Library of Sweden (e.g. Small: 7.3% word errors vs 20.6%).
  - **Norwegian**: NB-Whisper by the National Library of Norway (Bokmål and Nynorsk).
  - **Finnish**: by the Finnish-NLP community (Medium and Large v3).
  - **Russian**: Large v3 Turbo fine-tuned on Russian Common Voice by dvislobokov (MIT licence).

  **Tested:** on 40 real recordings per language from the FLEURS test set, the general
  *Large v3 Turbo (compressed)* was more accurate than both of these packs, so the app recommends
  it for Finnish and Russian and shows the results next to the packs:

  | Word errors (lower is better) | Finnish | Russian |
  |---|---|---|
  | General Small | 26.6% | 10.5% |
  | **General Large v3 Turbo (compressed)** | **6.6%** | **4.1%** |
  | Finnish Medium pack | 11.8% | – |
  | Russian pack | – | 8.4% (it also writes numbers as words) |

  Finnish Large v3 (3.1 GB) was not tested. The Swedish, Norwegian and English packs were not
  tested either; their publishers report clear gains over the general models.
  - **English**: English-only Whisper models and Distil-Whisper Large v3.5.

  The Finnish and Russian files are published uncompressed, so the app compresses them right
  after downloading (with whisper.cpp's `whisper-quantize`, to q5_0): about a third of the size,
  faster, with very little accuracy loss. If that tool is missing the uncompressed file is kept.
  Packs only exist where someone has published a fine-tuned model in whisper.cpp (ggml) format.
  You can also drop any whisper.cpp `ggml-*.bin` file into `models/`; it appears in the list.

**Key moments (local LLM)**
- **LM Studio** (fully managed): *On* starts the LM Studio server and loads the selected model;
  *Off* unloads all models and stops the server. Pick any LLM you've downloaded in LM Studio.
  Switching models unloads the old one first, so only one uses memory. **Context length** sets
  how much text the model reads at once (changing it while on reloads the model).
- **Other server**: any OpenAI-compatible server you run yourself (Ollama, `llama-server`, …).
  Enter its URL, press Connect, pick a model.
- **Write key moments in**: the recording's language, or always English. Small models such as
  Mistral 7B write English well but other languages poorly; choose English, or a multilingual
  model (e.g. Qwen or Gemma in LM Studio), for recordings in other languages.
- When the LLM is off, recordings are still transcribed and key moments are skipped. The recording
  then offers **Turn on LLM & summarize**. **Regenerate** re-runs key moments with the current model.

Choices are saved in `settings.json`.

## Files

| Path | Contents |
|---|---|
| `recordings/<id>.wav` | the recording (16 kHz mono) |
| `transcripts/<id>.txt` | timestamped transcript + plain text |
| `transcripts/<id>.summary.txt` | key-moment bullets |
| `transcripts/<id>.json` | metadata used by the UI |

## Configuration (environment variables)

Most settings live in the Models panel; these are only needed for unusual setups.

| Variable | Default | |
|---|---|---|
| `WHISPER_MODEL` | `ggml-small.bin` | first-run default; afterwards chosen in the Models panel |
| `WHISPER_LANGUAGE` | `auto` | first-run default |
| `WHISPER_SERVER_PORT` | `8178` | port for the in-memory `whisper-server` |
| `LLM_BASE_URL` | unset | first-run default. Without it: LM Studio if installed, otherwise Ollama's URL (“Other server”) |
| `LLM_MODEL` | first LLM downloaded in LM Studio | first-run default |
| `FFMPEG_BIN`, `WHISPER_BIN`, `WHISPER_SERVER_BIN` | found automatically | paths to use specific `ffmpeg` / `whisper-cli` / `whisper-server` binaries |
| `LLM_CHUNK_CHARS` | `6000` | longer transcripts are summarized in chunks, then merged |
| `PORT` | `5050` | |
| `NO_BROWSER` | unset | `1` = don't open the browser (run.sh) |
| `WHISPER_CPP_VERSION`, `WHISPER_CMAKE_FLAGS` | `1.9.4`, none | version and extra CMake flags when run.sh builds whisper.cpp |
